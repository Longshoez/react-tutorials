import React from 'react'

const Todo = ({ text, todo, todos, setTodos }) => {
    //events
    const deleteHandler = () => {
        setTodos(todos.filter(el => el.id !== todo.id))
    };

    const completedHandler = () =>{
        setTodos(todos.map(item => {
            if(item.id === todo.id){
                return{
                    //takes all properties out and only selects the "completed" one
                    ...item, completed: !item.completed
                }
            }
            return item;
            
        }))
        //deleteHandler(); we dont need to deleted but Strikethrout-it
    };

    return (
        <div className="todo">
            {/*ternary operator to toggle between classes */}
            <li className={`todo-item ${todo.completed ? "completed" : ""}`}>{text}</li>
            <button onClick ={completedHandler} className="complete-btn"><i className="fas fa-check"></i></button>
            <button onClick={deleteHandler} className="trash-btn"><i className="fas fa-trash"></i></button>
        </div>
    )
}

export default Todo
